
import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyAU68StjdiX6bD2OlmMqrs0sbUcdBnnemU",
  authDomain: "jewelleryapp-65114.firebaseapp.com",
  projectId: "jewelleryapp-65114",
  storageBucket: "jewelleryapp-65114.firebasestorage.app",
  messagingSenderId: "206697975797",
  appId: "1:206697975797:web:fc13d2d29c75c12ea61abc"
};

const app = initializeApp(firebaseConfig);