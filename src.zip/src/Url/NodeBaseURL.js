const baseURL = "http://localhost:5000"; // Replace with your actual base URL

export default baseURL;