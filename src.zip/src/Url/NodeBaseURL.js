

// const baseURL = "http://46.37.122.105:81/"; 

const baseURL = "http://localhost:5000"; 


export default baseURL;