import React from 'react'

const Rates = () => {
  return (
    <div>Rates</div>
  )
}

export default Rates