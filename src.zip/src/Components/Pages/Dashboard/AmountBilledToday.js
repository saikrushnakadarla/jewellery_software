import React from 'react'

function AmountBilledToday() {
  return (

    <div>
      <h3>Amount Billed</h3>
      <p style={{fontSize:'25px', marginTop:'20px'}}>
        <strong>
        ₹ 100000
        </strong>
      </p>
    </div>
  )
}

export default AmountBilledToday