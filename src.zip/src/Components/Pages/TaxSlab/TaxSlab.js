import React from 'react'

const TaxSlab = () => {
  return (
    <div>TaxSlab</div>
  )
}

export default TaxSlab