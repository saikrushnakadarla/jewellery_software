import React from 'react'

const CompanyInfo = () => {
  return (
    <div>
      CompanyInfo
    </div>
  )
}

export default CompanyInfo
