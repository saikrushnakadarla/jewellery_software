import React from 'react'

const CompanyTable = () => {
  return (
    <div>
      
    </div>
  )
}

export default CompanyTable
